# EarningsIQ — Financial Report Intelligence

> RAG pipeline for querying financial reports in plain English — retrieval-augmented generation with TF-IDF built from scratch, no external vector DB

![Python](https://img.shields.io/badge/Python-3.11-3776AB?logo=python&logoColor=white)
![FastAPI](https://img.shields.io/badge/FastAPI-0.111-009688?logo=fastapi&logoColor=white)
![Claude API](https://img.shields.io/badge/Claude-API-orange)
![RAG](https://img.shields.io/badge/Architecture-RAG-purple)
![Docker](https://img.shields.io/badge/Docker-ready-2496ED?logo=docker&logoColor=white)

![EarningsIQ Q&A Interface](preview.png)

---

## What It Does

Upload any financial report (annual report, earnings release, 10-K), ask questions in plain English, and get **grounded, cited answers**. EarningsIQ shows you exactly which passages it retrieved to generate each answer — no hallucinations, full transparency.

**Live demo:** open `frontend/index.html` in any browser. Works in demo mode without an API key — 4 built-in reports included.

---

## Features

### Q&A Chat
- Ask any question about a selected report
- TF-IDF retrieval finds the top 4 most relevant passages
- Each answer shows the retrieved passages with relevance scores and animated score bars
- Answers formatted with **bold numbers** for fast scanning
- Works in demo mode (pre-loaded answers) or live mode (Anthropic API key)

### Compare Reports
- Side-by-side financial metrics across all loaded reports
- 4 comparison views: Net Profit, Growth Rates, Dividends, All Metrics
- Winner highlighted per metric — AI insight summary auto-generated

### Key Metrics Dashboard
- Extracted KPIs displayed as cards with animated progress bars
- One-click to jump to Q&A for any report

### Upload Your Own Report
- Drop any `.txt` file (plain text extracted from a PDF)
- Auto-chunked and indexed — immediately queryable
- Works with live Claude API for full AI-generated answers

---

## RAG Architecture

```
Document text
      ↓  Chunker: 500-token windows, 80-token overlap
Chunks array
      ↓  TF-IDF Index: term frequency × inverse document frequency per chunk
In-memory index
      ↓  Query → tokenise → cosine similarity scoring against all chunks
Top-4 passages (with relevance %)
      ↓  Context + question → Claude API (claude-3-haiku)
Grounded answer — uses ONLY retrieved passages
```

### Why TF-IDF instead of embeddings?

For financial reports, TF-IDF reliably matches exact figures like "SGD 10.3 billion" or "CET-1 14.6%" without the risk of dense embeddings subtly changing numbers. The retriever is implemented from scratch (no LangChain, no Chroma, no FAISS) — just term frequency maths — which demonstrates genuine understanding of the retrieval mechanism.

In production, the optimal approach is hybrid: BM25 + dense retrieval with a cross-encoder reranker (e.g. Cohere Rerank). The architecture is designed to swap this in.

---

## Tech Stack

**Backend:** FastAPI · custom TF-IDF retriever (no external vector DB) · httpx async Claude API calls · Pydantic v2

**Frontend:** Vanilla JS · Fraunces serif + DM Mono type system · CSS IntersectionObserver animations

**Infrastructure:** Docker + Docker Compose · `.env` for API key management

---

## Built-in Reports

| Report | Type | Key Metrics |
|---|---|---|
| DBS Group FY2023 | Singapore bank annual report | $10.3B net profit, +26% YoY, 18% ROE |
| Singapore Airlines FY2023/24 | Aviation annual report | $2.67B profit, 35.3M passengers |
| Goldman Sachs Q4 2023 | US investment bank earnings | $46.3B revenue, $2.81T AUM |
| EY Global FY2023 | Big 4 consulting revenue | $49.4B revenue, +14.2% growth |

Each report has 8 pre-loaded Q&A pairs covering profit, dividends, growth, risks, and sector-specific metrics.

---

## Quick Start

```bash
git clone https://github.com/nobaadi/earningsiq
cd earningsiq

# Add your Anthropic API key (optional — demo mode works without it)
cp backend/.env.example backend/.env

# Docker
docker-compose up --build
# Frontend: http://localhost:3000
# API docs: http://localhost:8000/docs

# Or just open frontend/index.html in your browser
```

---

## API Endpoints

```
POST /api/ingest              chunk and index a document
POST /api/query               retrieve + generate answer
GET  /api/documents           list indexed documents
DELETE /api/documents/{id}    remove a document
GET  /health                  service status
```

**Example request:**
```json
POST /api/query
{
  "document_id": "dbs_fy2023",
  "query": "What was the net profit and dividend per share?",
  "api_key": "sk-ant-..."
}
```

**Example response:**
```json
{
  "answer": "DBS reported a record net profit of **SGD 10.3 billion**...",
  "retrieved": [
    {"text": "DBS Group Holdings reported a record...", "score": 99, "index": 0},
    {"text": "The board declared a final dividend...", "score": 74, "index": 2}
  ],
  "model": "claude-3-haiku-20240307"
}
```

---

## Project Structure

```
earningsiq/
├── backend/
│   ├── app/
│   │   ├── main.py              FastAPI app with 5 endpoints
│   │   └── services/
│   │       └── rag.py           TF-IDF index + chunker + Claude API
│   ├── requirements.txt
│   └── .env.example
├── frontend/index.html          full SPA — Q&A, Compare, Metrics
├── docker-compose.yml
└── README.md
```
