"""
RAG Pipeline
------------
1. Ingest:   Split document into 500-token chunks with 80-token overlap
2. Index:    Build TF-IDF term matrix for each document in memory
3. Retrieve: Score chunks by query relevance using cosine similarity
4. Generate: Send top-k chunks as context to Claude API, get grounded answer
"""

import re
import math
import httpx
import logging
from collections import defaultdict

logger = logging.getLogger(__name__)

CHUNK_SIZE = 500      # tokens (approx words)
CHUNK_OVERLAP = 80
TOP_K = 4


class TFIDFIndex:
    """Lightweight in-memory TF-IDF retriever — no external vector DB needed."""

    def __init__(self):
        self.chunks: list[dict] = []       # [{text, start, end, index}]
        self.tf_matrix: list[dict] = []    # term frequencies per chunk
        self.idf: dict[str, float] = {}
        self.vocab: set[str] = set()

    def _tokenize(self, text: str) -> list[str]:
        return re.findall(r'\b[a-z]{2,}\b', text.lower())

    def _tf(self, tokens: list[str]) -> dict[str, float]:
        freq = defaultdict(int)
        for t in tokens:
            freq[t] += 1
        total = len(tokens) or 1
        return {t: c/total for t, c in freq.items()}

    def build(self, chunks: list[str]):
        self.chunks = [{"text": c, "index": i} for i, c in enumerate(chunks)]
        token_lists = [self._tokenize(c) for c in chunks]
        self.tf_matrix = [self._tf(tl) for tl in token_lists]
        N = len(chunks)
        doc_freq = defaultdict(int)
        for tl in token_lists:
            for t in set(tl):
                doc_freq[t] += 1
        self.idf = {t: math.log((N+1)/(df+1))+1 for t, df in doc_freq.items()}
        self.vocab = set(doc_freq.keys())

    def query(self, q: str, k: int = TOP_K) -> list[dict]:
        q_tokens = self._tokenize(q)
        q_tf = self._tf(q_tokens)
        q_vec = {t: q_tf[t]*self.idf.get(t,0) for t in q_tokens}
        q_norm = math.sqrt(sum(v**2 for v in q_vec.values())) or 1

        scores = []
        for i, tf in enumerate(self.tf_matrix):
            tfidf = {t: tf.get(t,0)*self.idf.get(t,0) for t in q_vec}
            dot = sum(q_vec[t]*tfidf[t] for t in q_vec)
            norm = math.sqrt(sum(v**2 for v in tfidf.values())) or 1
            scores.append((dot/(q_norm*norm), i))

        scores.sort(reverse=True)
        return [{"text": self.chunks[i]["text"], "score": round(s*100,1), "index": i}
                for s,i in scores[:k] if s > 0]


class RAGPipeline:
    def __init__(self):
        self._indexes: dict[str, TFIDFIndex] = {}
        self._meta: dict[str, dict] = {}

    def _chunk_text(self, text: str) -> list[str]:
        words = text.split()
        chunks, start = [], 0
        while start < len(words):
            end = min(start + CHUNK_SIZE, len(words))
            chunks.append(" ".join(words[start:end]))
            start += CHUNK_SIZE - CHUNK_OVERLAP
        return chunks

    def ingest(self, doc_id: str, text: str, title: str) -> int:
        chunks = self._chunk_text(text)
        idx = TFIDFIndex()
        idx.build(chunks)
        self._indexes[doc_id] = idx
        self._meta[doc_id] = {"title": title, "chunks": len(chunks), "chars": len(text)}
        logger.info(f"Indexed '{title}': {len(chunks)} chunks")
        return len(chunks)

    def delete(self, doc_id: str):
        self._indexes.pop(doc_id, None)
        self._meta.pop(doc_id, None)

    def list_documents(self) -> list[dict]:
        return [{"id": k, **v} for k, v in self._meta.items()]

    async def query(self, doc_id: str, question: str, api_key: str) -> dict:
        if doc_id not in self._indexes:
            return {"error": "Document not indexed", "answer": None, "retrieved": []}

        retrieved = self._indexes[doc_id].query(question, k=TOP_K)
        if not retrieved:
            return {"answer": "No relevant passages found for this question.", "retrieved": []}

        context = "\n\n---\n\n".join(
            f"[Passage {i+1}]\n{r['text']}" for i, r in enumerate(retrieved)
        )

        prompt = f"""You are a financial analyst assistant. Answer the question using ONLY the passages provided below. 
If the answer is not in the passages, say so clearly. Be specific and cite passage numbers.

PASSAGES:
{context}

QUESTION: {question}

ANSWER:"""

        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                "https://api.anthropic.com/v1/messages",
                headers={
                    "x-api-key": api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json",
                },
                json={
                    "model": "claude-3-haiku-20240307",
                    "max_tokens": 800,
                    "messages": [{"role": "user", "content": prompt}],
                },
            )

        if resp.status_code != 200:
            return {"error": f"Claude API error {resp.status_code}", "answer": None, "retrieved": retrieved}

        data = resp.json()
        answer = data["content"][0]["text"] if data.get("content") else "No response"
        return {"answer": answer, "retrieved": retrieved, "model": "claude-3-haiku-20240307"}
