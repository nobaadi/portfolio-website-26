from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from app.services.rag import RAGPipeline
import os

app = FastAPI(
    title="EarningsIQ API",
    description="RAG pipeline for financial report Q&A using Claude",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

rag = RAGPipeline()


class QueryRequest(BaseModel):
    query: str
    api_key: str
    document_id: str


class IngestRequest(BaseModel):
    document_id: str
    text: str
    title: str


@app.post("/api/ingest")
async def ingest_document(req: IngestRequest):
    """Chunk and index a document for RAG retrieval."""
    chunk_count = rag.ingest(req.document_id, req.text, req.title)
    return {"document_id": req.document_id, "chunks": chunk_count, "status": "indexed"}


@app.post("/api/query")
async def query_document(req: QueryRequest):
    """Retrieve relevant chunks and generate a grounded answer via Claude API."""
    if not req.api_key.startswith("sk-ant-"):
        raise HTTPException(status_code=400, detail="Invalid Anthropic API key format")
    result = await rag.query(req.document_id, req.query, req.api_key)
    return result


@app.get("/api/documents")
async def list_documents():
    return {"documents": rag.list_documents()}


@app.delete("/api/documents/{document_id}")
async def delete_document(document_id: str):
    rag.delete(document_id)
    return {"deleted": document_id}


@app.get("/health")
async def health():
    return {"status": "ok", "service": "earningsiq"}
