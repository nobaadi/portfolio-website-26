from fastapi import APIRouter, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import text
from app.db.database import get_db

router = APIRouter()


@router.get("/")
async def list_transactions(
    town: str = None,
    flat_type: str = None,
    min_price: float = None,
    max_price: float = None,
    month_from: str = None,
    month_to: str = None,
    page: int = Query(1, ge=1),
    page_size: int = Query(50, le=200),
    db: AsyncSession = Depends(get_db),
):
    filters = []
    if town:        filters.append(f"town = '{town}'")
    if flat_type:   filters.append(f"flat_type = '{flat_type}'")
    if min_price:   filters.append(f"resale_price >= {min_price}")
    if max_price:   filters.append(f"resale_price <= {max_price}")
    if month_from:  filters.append(f"month >= '{month_from}'")
    if month_to:    filters.append(f"month <= '{month_to}'")
    where = "WHERE " + " AND ".join(filters) if filters else ""
    offset = (page - 1) * page_size

    count_r = await db.execute(text(f"SELECT COUNT(*) FROM transactions {where}"))
    total = count_r.scalar()

    r = await db.execute(text(f"""
        SELECT * FROM transactions {where}
        ORDER BY month DESC, resale_price DESC
        LIMIT {page_size} OFFSET {offset}
    """))
    rows = [dict(row) for row in r.mappings()]
    return {"total": total, "page": page, "page_size": page_size, "data": rows}
