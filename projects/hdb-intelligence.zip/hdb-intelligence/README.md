# HDB Resale Intelligence Platform

> End-to-end data pipeline and analytics dashboard for Singapore HDB resale market — built on real government transaction data

![Python](https://img.shields.io/badge/Python-3.11-3776AB?logo=python&logoColor=white)
![FastAPI](https://img.shields.io/badge/FastAPI-0.111-009688?logo=fastapi&logoColor=white)
![SQLite](https://img.shields.io/badge/SQLite-async-003B57?logo=sqlite&logoColor=white)
![Docker](https://img.shields.io/badge/Docker-ready-2496ED?logo=docker&logoColor=white)
![Data](https://img.shields.io/badge/Data-data.gov.sg-red)

![HDB Intelligence Dashboard](preview.png)

---

## What It Does

Ingests **~8,000 real HDB resale transactions** from the [data.gov.sg](https://data.gov.sg/datasets/d_8b84c4ee58e3cfc0ece0d773c8ca6abc/view) public API, runs a full **Extract → Transform → Load** pipeline into a SQLite database, then surfaces insights through a 6-tab interactive analytics dashboard.

**Live demo:** open `frontend/index.html` directly in any browser — no backend required.

---

## Dashboard Features

| Tab | What You Can Do |
|---|---|
| **Overview** | 54-month price trend, flat type composition, year-on-year growth, storey premium analysis |
| **Deal Finder** | Filter by flat type / town / year — ranked by % below market average for that exact town × type combination |
| **Price Predictor** | Input any configuration and get an estimated price anchored to real medians, with storey, town and lease comparison charts |
| **Explorer** | Filter and search all transactions with pagination and colour-coded lease-risk badges |
| **Town Map** | Heatmap of all 26 towns — click any town to drill into its own trend and flat type breakdown vs market |
| **Compare Towns** | Head-to-head stats comparison with dual price trend chart |

---

## ETL Pipeline

```
data.gov.sg REST API
      ↓  httpx async fetch (paginated, retry on 429)
Raw JSON records
      ↓  pandas: type coercion, null validation, price_per_sqm derived
Clean DataFrame (~99.8% pass rate)
      ↓  SQLAlchemy async bulk insert
SQLite database
      ↓  Compound indexes: (month, town) and (town, flat_type)
FastAPI analytics endpoints
      ↓  SQL: trend, YoY, storey premium, heatmap, paginated explorer
Interactive dashboard
```

---

## Tech Stack

**Backend:** FastAPI · SQLAlchemy 2.0 async · aiosqlite · httpx · pandas · numpy

**Frontend:** Vanilla JS · Chart.js · IntersectionObserver animations · no build step

**Infrastructure:** Docker + Docker Compose · configurable via `.env`

---

## Key SQL Analytics

```sql
-- Year-on-year price growth
SELECT SUBSTR(month, 1, 4) AS year,
       ROUND(AVG(resale_price), 0) AS avg_price,
       COUNT(*) AS volume
FROM transactions
GROUP BY year ORDER BY year;

-- Below-market deal detection
SELECT t.*, (t.resale_price - a.avg_price) / a.avg_price AS pct_vs_avg
FROM transactions t
JOIN (SELECT town, flat_type, AVG(resale_price) AS avg_price
      FROM transactions GROUP BY town, flat_type) a
  ON t.town = a.town AND t.flat_type = a.flat_type
ORDER BY pct_vs_avg ASC;
```

---

## Quick Start

```bash
git clone https://github.com/nobaadi/hdb-intelligence
cd hdb-intelligence
docker-compose up --build
# Backend API: http://localhost:8000/docs
# Frontend:    http://localhost:3000

# Or just open frontend/index.html in your browser
```

---

## API Endpoints

```
GET /api/analytics/summary         KPI totals
GET /api/analytics/trend           monthly avg price (filterable)
GET /api/analytics/by-town         26-town heatmap data
GET /api/analytics/yoy             year-on-year price change
GET /api/analytics/storey-premium  floor band price uplift
GET /api/transactions              paginated explorer with filters
GET /api/towns                     list of towns and flat types
```

---

## Data Source

**HDB Resale Flat Prices** — Singapore Government Open Data  
[data.gov.sg](https://data.gov.sg/datasets/d_8b84c4ee58e3cfc0ece0d773c8ca6abc/view) · Resource ID: `d_8b84c4ee58e3cfc0ece0d773c8ca6abc`

~8,000 transactions · Jan 2020 – Jun 2024 · 26 planning areas  
Median prices verified against HDB Resale Price Index (RPI: 2020=100.0, 2024=138.5)

---

## Project Structure

```
hdb-intelligence/
├── backend/
│   ├── app/
│   │   ├── main.py              FastAPI app + lifespan ETL trigger
│   │   ├── db/database.py       async SQLAlchemy engine
│   │   ├── models/models.py     Transaction ORM + compound indexes
│   │   ├── routers/
│   │   │   ├── analytics.py     5 SQL analytics endpoints
│   │   │   ├── transactions.py  paginated explorer with multi-filter
│   │   │   └── towns.py
│   │   └── services/etl.py      Extract → Transform → Load
│   ├── requirements.txt
│   └── .env.example
├── frontend/index.html          standalone dashboard
├── docker-compose.yml
└── README.md
```
